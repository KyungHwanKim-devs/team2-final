package com.khit.recruit;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Final_team2_testApplication {

	public static void main(String[] args) {
		SpringApplication.run(Final_team2_testApplication.class, args);
	}

}
