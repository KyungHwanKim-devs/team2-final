package com.khit.recruit.entity;

public enum Role {
	MEMBER,
	COMPANY,
	ADMIN
}
